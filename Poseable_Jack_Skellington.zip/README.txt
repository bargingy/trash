                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1892351
Poseable Jack Skellington by ModernGnome is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

What is this? It's Jack Skellington, The Pumpkin King from The Nightmare Before Christmas.

This model is still subject to change, although the first test print went surprisingly well. It requires little or no support. I did not use raft, although your printer might require it.

I plan on developing some accessories -- but why wait? Add your own Santa hat, pumpkin head, or use a heat gun to adjust the fingers for that perfect "Sandy Claws" pose. 

How horrible our Christmas will be!


# Post-Printing

Paint with acrylics. (Optional: use a fine-tipped white-ink pen for the pinstripes.)
Glue the feet to your choice of base (not included).

If the model is printed smaller (or, depending on your printer, perhaps even larger) than 100% size, the ball-and-socket joints are unlikely to work reliably. I used a heat gun here and there to adjust tolerances and stick a few parts together.

Attach the upper and lower body halves with the double-ended pin connector.

For a more poseable model, drill small holes in the arms and legs and insert wires from straightened paper clips. Or remix it with bigger holes for elastic cords!

**Update:** V2 splits the coat tails from the body, in case you've had trouble printing them.

# How I Designed This

Cut, rotated, repaired and plated with Microsoft 3D Builder. If you want to ungroup the parts, 3D Builder works well for that, too. Two sets of hands are provided, one of which was sculpted in MeshMixer.

This remix currently includes ball-and-socket joints based on http://www.thingiverse.com/thing:584405, although this is likely to change, as the joints for hips, elbows, etc., should be sculpted to suit the range of movement. (A small piece of filament might work well as a hinge-point in each joint to hold the pieces together, too.)